module.exports= {
    user: 'sa', //user name
    password: 'icreate', //user password
    server: '192.168.1.118', // You can use 'localhost\\instance' to connect to named instance
    database: 'DemoNode' //database name
     // options: {
    //     encrypt: true // Use this if you're on Windows Azure
    // }
}

// module.exports = config // another method of export modules