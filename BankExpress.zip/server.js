const express = require('express')
const path = require('path')
var bodyParser = require('body-parser')
var bankController = require('./controller/bankController')

const app = express()
app.use(bodyParser.urlencoded({ extended: false }))
// app.use(bodyParser.json())
app.set('view engine','ejs')
// app.set('views',path.join(__dirname,'/controller'))

bankController(app)
//Routes
app.get('/',(req,res)=>{res.render('pages/home')})
app.get('/create_account',(req,res)=>{res.render('pages/create_account')})
app.get('/account_info',(req,res)=>{res.render('pages/account_info')})
app.get('/deposit',(req,res)=>{res.render('pages/deposit')})
app.get('/withdrawal',(req,res)=>{res.render('pages/withdrawal')})
app.get('/print_passbook',(req,res)=>{res.render('pages/print_passbook')})
app.get('/close_account',(req,res)=>{res.render('pages/close_account')})
const PORT = process.env.PORT || 3000

app.listen(PORT,()=>console.log('Listning on Port 3000'))