var dbApi = require('../dbCallApi')

module.exports =  (app)=>
{
    app.get('/bankController',(req,res)=> res.send("HelloWorld"))
    app.post('/bankController', (req, res)=>{
        dbApi.SelectAccountNo().then((result) => {
            var accno=0;
         
            if(result.length>0)
             {
                 accno = parseInt(result)+1 
               
             }
             else
             {
                accno=100
             } 

             dbApi.CreateAccount(accno, req.body.name,req.body.address ,req.body.phoneno,req.body.account_type)
                .then((result) => {
                    if(result>0)
                    {
                        dbApi.InsertActiveAccount(accno).then((result)=>{
                            if(result>0)
                            {
                              let  description = `DEPOSITE: ${req.body.dpamount}`
                               let date = convert(new Date())
                               let time = new Date().toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true })
                                dbApi.InsertPassBook(accno,date,time,req.body.dpamount,description).then((result)=>{
                                    if(result>0)
                                    {
                                        // let msg = 'Successfully Account was created.'+`Thank You for be with us: ${req.body.name}.`+`Your Account No is : ${accno}`
                                        // res.writeHead(301,
                                        //     {Location: 'http://localhost:3000/create_account'+msg}
                                        //   );

                                        //   res.format({
                                        //      'application/json': function () {
                                        //       res.send({ message: 'Successfully Account was created.'+`Thank You for be with us: ${req.body.name}.`+`Your Account No is : ${accno}`})
                                        //     },})
                                        res.send('Successfully Account was created.'+`Thank You for be with us: ${req.body.name}.`+`Your Account No is : ${accno}`)    
                                        
                                    }
                                    else{
                                        res.send(`Something wrong`)
                                    }
                                   
                                }).catch(err => res.send(err))   
                            }
                            else{
                                    res.send(`something wrong.!`)
                            }
                                             
                        }).catch(err => console.log(err))
                    }
                    else{
                            res.send(`something went wrong.!`)
                    }
                   
                })
                .catch(err => res.send(err)) 
        
         }).catch(err =>res.send(err))
        // res.send('welcome, ' + req.body.name)
    } )


}
function convert(str) {
    var date = new Date(str),
        mnth = ("0" + (date.getMonth()+1)).slice(-2),
        day  = ("0" + date.getDate()).slice(-2);
    return [ date.getFullYear(), mnth, day ].join("-");
  }